function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6DFlQqUD6P0":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

